package com.example.chat_app.models;

import java.util.Date;

public class ChatMessage {
    public String senderId, receiverId, message, dateTime;
    public Date dateObject;
}
 // בנאי דפולטיבי