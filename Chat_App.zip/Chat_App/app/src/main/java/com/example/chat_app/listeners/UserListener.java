package com.example.chat_app.listeners;

import com.example.chat_app.models.User;

public interface UserListener {
    void onUserClicked(User user);
}
